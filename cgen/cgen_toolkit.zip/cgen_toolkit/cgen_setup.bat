@echo off
title Trainstorm CGEN - One-Time Setup
color 1F
echo.
echo  =====================================================
echo   Trainstorm CGEN Toolkit - One-Time Setup
echo  =====================================================
echo.
echo  This will check your Python installation and install
echo  all required packages. This only needs to run once.
echo.
pause

:: -------------------------------------------------------
:: Check Python
:: -------------------------------------------------------
echo.
echo  Checking for Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo  [ERROR] Python was not found on this machine.
    echo.
    echo  Please install Python from:
    echo    https://www.python.org/downloads/
    echo.
    echo  IMPORTANT: During installation, check the box that
    echo  says "Add Python to PATH" before clicking Install.
    echo.
    echo  Then re-run this setup file.
    echo.
    pause
    exit /b 1
)

for /f "tokens=*" %%V in ('python --version 2^>^&1') do set PY_VER=%%V
echo  Found: %PY_VER%
echo.

:: -------------------------------------------------------
:: Install pip packages
:: -------------------------------------------------------
echo  Installing required packages (this may take a minute)...
echo.

pip install --quiet --disable-pip-version-check ^
    python-pptx ^
    python-docx ^
    openpyxl ^
    pdfplumber ^
    pdf2image ^
    pytesseract

if errorlevel 1 (
    echo.
    echo  [WARNING] One or more packages may not have installed correctly.
    echo  Try running this file again. If the problem persists, contact Jake.
    echo.
    pause
    exit /b 1
)

:: -------------------------------------------------------
:: Check for Tesseract (needed only for scanned PDFs)
:: -------------------------------------------------------
echo.
where tesseract >nul 2>&1
if errorlevel 1 (
    echo  NOTE: Tesseract OCR is not installed on this machine.
    echo  This is only needed if you process scanned PDFs.
    echo  Regular PDFs, Word docs, PowerPoints and Excel files
    echo  will work fine without it. If you need OCR, contact Jake.
) else (
    echo  Tesseract OCR: Found
)

echo.
echo  =====================================================
echo   Setup complete!
echo.
echo   You can now use cgen_build.bat to run the pipeline.
echo  =====================================================
echo.
pause
