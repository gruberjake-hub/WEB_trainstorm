# Beta harness — thinnest end-to-end slice (SOP-AST-29080 / ALSAP)

Proves the loop: **raw corpus → atoms → validation gate → deterministic projection**.
Everything here was produced in a Cowork session workspace. It is a **self-contained mirror**, not
your repo — nothing here has touched the real registries. To land it, place each piece where noted
and commit `registry_adds/` to the Astellas registries.

## Run order
```
python3 tools/headwater_ingest.py       # SOP -> atoms.json (+ staging pen, source_silent, manifest)
python3 tools/validate_atoms.py         # the standing gate (schema / drift / vocab-conformance)
python3 tools/adopt_registries.py       # promote proposals -> registries (v-bump) + registry_adds/
python3 tools/project_sop.py            # atoms -> controlled_sop_ast29080.html (labels VLOOKUP'd from registries)
# --- reconcile round-trip (makes the loop bidirectional) ---
python3 tools/project_review_table.py   # atoms -> review_matrix.csv  (the surface the SME marks up)
#   SME fills proposed_source_text; review_matrix.filled.csv here is a SIMULATED markup (2 edits)
python3 tools/reconcile.py review_matrix.filled.csv   # edits -> canon: source_text, content_hash,
#   version+1, status->in_review; audit trail appended to reconciliation_log.json (external, by atom_id)
# --- approval / publish gate (finishes the lifecycle: draft -> in_review -> approved) ---
python3 tools/approve.py --approver role_safety_programmer   # REFUSED — not a governed approver
python3 tools/approve.py --approver role_alsap_approver      # approved + effective_date; signs approvals.json
python3 tools/project_sop.py                                 # re-project: header now reads APPROVED + effective date
```

Note: `headwater_ingest.py` is a one-time origin write — re-running it regenerates atoms.json at
baseline (v1/draft) and **clobbers reconcile edits**. In this snapshot the store is in its
*reconciled* end-state (two atoms at v2/in_review); re-run ingest only to reset to origin.

## Core schemas: read from canon, never from a copy
The three core-canon files (`atom.schema.json`, `procedure.facet.schema.json`, `procedure.enum.json`)
live once, in `cgen/trainstorm-core/`. This package does **not** keep committable copies next to the
tools — they sit in `_core_mirror/` (fenced, byte-identical, clearly marked) purely so the harness can
run outside a checkout. In the repo, run the gate against canon:

```
python3 tools/validate_atoms.py --core-dir <path>/cgen/trainstorm-core
```

Without `--core-dir` it prints a WARNING and falls back to the mirror. This closes the drift hole that
caused commit `c6ad256` (vendored copies overwrote core). Note: `procedure.enum.json` is the real
`dimensions`-nested shape now — governed values are `dimensions.<name>.values[].id`, and the validator
reads them there.

## If a tool throws — fault triage (read this before you panic)

Two breaks are *predictable* here, and neither is you or the AI — both are the **system** (files
moved or changed shape). Match the error, apply the one-line fix.

| You'll see | What it means | The fix |
|---|---|---|
| `FileNotFoundError: .../schemas/...` or `.../store/...` | You moved files into the `cgen/astellas/…` layout, but the tools still point at the old flat paths. | Repoint the two path vars at the top of each tool: `SCH = …` (→ core schemas + `astellas/registry`) and `STORE = …` (→ `astellas/projects/ast_alsap`). Core schemas and registries now live in **two** folders. |
| `TypeError: unhashable type: 'dict'` | A loader is reading a v3 registry (entries are now `{id, label, …}` objects) as if it were a flat list of id strings. | Pull the ids out of the objects: `set(reg["roles"])` → `{e["id"] for e in reg["roles"]}`. Already fixed in the shipped tools — this bites only if you hand-write a new loader. |

Rule of thumb: a `FileNotFoundError` naming a path = a *location* moved; a `TypeError`/`KeyError` on a
registry = a *shape* changed. Both are system faults with one-line fixes — not a reasoning failure.

## Layout → where it belongs in the repo
| Here | Belongs in repo | Notes |
|---|---|---|
| `_core_mirror/{atom.schema,procedure.facet.schema,procedure.enum}.json` | **already in `cgen/trainstorm-core/`** | Byte-identical MIRROR of canon, fenced so it can't be committed over core. Tools read canon via `--core-dir`; the mirror is a standalone-run fallback only. **Do not copy these into core.** See `_core_mirror/DO_NOT_COMMIT_TO_CORE.md`. |
| `schemas/{roles,records,docs}.registry.json` | **Astellas client namespace** | v3 = post-adoption **simulation**. Entries are `{id, label, description}` (docs also `source_number`) — the label is what the projector renders. The real adds are `registry_adds/`. |
| `store/projects/ast_alsap/` | per-project content store (project = repo/namespace) | The atom store + transient staging. |
| `registry_adds/*.add.json` | apply to the real client registries | The exact commit payloads (roles +10, records +4, docs +13). |
| `tools/*` | wherever the harness runner lives | Thin Python: ingest / validate / adopt / project. |
| `controlled_sop_ast29080.html` | (derived) | Regenerated, never hand-edited. |

## Reconcile round-trip (the return leg)
The SME never edits JSON. `project_review_table.py` emits `review_matrix.csv` (one row per step,
current text + an empty `proposed_source_text` column). They fill it; `reconcile.py` folds edits
back into canon, matched by `atom_id`. Honest finding baked in here: the atom's `governance` object
is `additionalProperties:false` and has **no field for review provenance** (who/when/why/from-hash),
so the audit trail lives in an **external `reconciliation_log.json`, keyed by atom_id** — the same
"reference, don't embed" move as locale packs. The atom just gets a new hash, version bump, and status.

## Approval / publish gate (finishes the lifecycle)
`approve.py` is the one gate canon says must enforce sequencing — pre-publish QA. Two hard
preconditions: (1) the approver is one of the project's governed `approval_roles` (declared in
`manifest.json`), and (2) the standing gate reads GATE PASS **and** PROMOTE PASS. On pass it sets every
atom `status: approved`, appends `approved_by`, stamps `effective_date` — and does **not** touch
`meaning`, so `content_hash`/`version` are unchanged (unchanged hash = the approved content is the
validated content). Contrast with reconcile: the approval *outcome* has a native home in `governance`,
so it writes into the atom; only the signed *snapshot* (approver + date ↔ each `content_hash`) goes to
the external `approvals.json`.

## The staging pen
`store/projects/ast_alsap/proposed_registry_extensions.json` is **transient**. Proposals stage there,
get promoted UP into the client registries on adoption, and the pen is then dropped — the project only
*references* the now-governed ids. Do not let it become a shadow copy.

## Gate policy
HARD failures (schema invalid / unresolved ref / hash mismatch / **ungoverned-and-unproposed** value)
block at any status. PROPOSED-pending values pass at `draft` but block promotion to `in_review`/`approved`
until adopted. "Flag, never invent" is a gate verdict, not a slogan.

## Open threads carried out of this pass
- `list` / `list_item` as a **shared-core structural kind** (NOT procedure.enum) — front-matter lists
  are flagged, not smashed; re-decompose once the kind exists.
- Safety Programmer Developer/Validator → **one role + a per-step `duty` attribute** — needs a
  procedure facet version bump (facet is `additionalProperties:false`; don't invent the field locally).
- Embedded conditional in B.s2 — candidate `decision` step (kept atomic, flagged).
- Still owed: verify `atom.schema.json` + `procedure.enum.json` against live files; `reg_benefit_risk_profile`
  (untouched — BRT appears only as a role here).
