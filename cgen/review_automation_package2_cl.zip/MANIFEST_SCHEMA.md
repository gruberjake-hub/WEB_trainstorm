# Storyline Review Manifest — Schema Contract
_Version 1.0 — Trainstorm / CGEN Pipeline_

---

## Purpose

This document defines the canonical JSON schema for the Storyline Review
Manifest — the structured artifact that sits between the reconciliation
step and the `sl_apply.py` executor.

Every prompt profile that produces a manifest and every tool that consumes
one is written against this contract. The schema must not be altered by
individual profiles or execution contexts.

---

## Lifecycle position

```
Canon JSON + Reviewer CSV + Matrix DOCX
              ↓
   NORMALIZER (Step A)  ←── optional separate pass
              ↓
   RECONCILER (Step B)  ←── or GENERATOR (single pass)
              ↓
     manifest.json      ←── THIS SCHEMA
              ↓
   sl_apply.py executor
              ↓
   matrix_revised.docx  +  audit.json
```

---

## Top-level structure

```json
{
  "meta": { ... },
  "changes": [ ... ]
}
```

---

## `meta` object

Required. Describes the cycle and its inputs.

| Field           | Type   | Required | Description |
|-----------------|--------|----------|-------------|
| `course`        | string | yes      | Story filename (e.g. `ALSAP_vCUR_.story`) |
| `cycle`         | string | yes      | Cycle identifier (e.g. `2026-06`) |
| `author`        | string | yes      | Producing party |
| `description`   | string | yes      | Human-readable summary of the cycle |
| `canon_sources` | array  | yes      | List of canon document filenames used |
| `generated_by`  | string | no       | Profile used to generate (e.g. `MANIFEST_GENERATOR v1.0`) |
| `model`         | string | no       | LLM used if recorded |

---

## `changes` array

Each element is a **change entry** describing one targeted text modification.

A single reviewer comment may produce multiple change entries (e.g. when a
paragraph rewrite requires clearing multiple runs). Each entry is
independently addressable by the executor.

### Change entry fields

| Field           | Type    | Required | Description |
|-----------------|---------|----------|-------------|
| `id`            | string  | yes      | Storyline element ID from the matrix column 0 |
| `slide`         | string  | yes      | Slide name for human reference |
| `element_type`  | string  | yes      | Element type label from matrix column 1 |
| `disposition`   | string  | yes      | See Disposition values below |
| `reviewer`      | string  | yes      | Source reviewer name(s) |
| `canon_basis`   | string  | yes      | Rationale grounded in canon; empty string if N/A |
| `segment_index` | integer | yes      | Row within the ID group (0 = first). Default 0 |
| `run_index`     | integer | yes      | Run within the Translation cell paragraph (0 = first). Default 0 |
| `new_text`      | string  | yes      | Replacement text. Empty string clears the run |
| `notes`         | string  | no       | Developer notes (formatting, context, caveats) |
| `source_comment`| string  | no       | Verbatim or normalized reviewer comment for traceability |
| `review_flag`   | boolean | no       | True = flagged for human post-hoc review |

---

## Disposition values

| Value      | Executor behavior | Meaning |
|------------|-------------------|---------|
| `REVISE`   | Applied           | Change is canon-grounded and should be executed |
| `VERIFY`   | Skipped           | Requires SME or regulatory confirmation before action |
| `DEV_FIX`  | Skipped           | Storyline interaction / visual / technical fix; not a text change |
| `DEFERRED` | Skipped           | Out of scope for this cycle; flagged for future |
| `CONSIDER` | Skipped           | SME input needed; may or may not require revision |

Only `REVISE` entries are executed by `sl_apply.py`. All others are
recorded in the audit log with their disposition reason.

---

## Addressing model

The executor addresses each entry by `(id, segment_index, run_index)`:

- **`id`** — the Storyline element ID. Resolved at runtime against the
  live matrix. Never hardcoded as a row number.

- **`segment_index`** — which row within the ID's row group to target.
  Most elements are single-row (`segment_index: 0`). Multi-paragraph
  elements span multiple rows with the same ID; use `segment_index: 1`,
  `2`, etc. to target continuation rows.

- **`run_index`** — which run within the Translation cell to modify.
  Most cells have a single run (`run_index: 0`). Cells with mixed
  formatting (e.g. bold label + normal description) have multiple runs;
  use `run_index: 1` to target the non-bold description while leaving
  the bold label intact.

---

## Run index guidance (how to preserve formatting)

The Translation cell's run structure mirrors the Source Text formatting.
The executor replaces only the text content of the targeted run; bold,
italic, and other formatting properties are preserved automatically.

Common patterns:

| Pattern | run_index | Example |
|---------|-----------|---------|
| Plain text, single run | 0 | Narrative paragraphs, slide notes, table cells |
| Bold label + normal description | 0 = label (bold), 1 = description | `SMT (Safety Management Team): ` + `primary cross-functional...` |
| All-bold callout | 0 | Button labels, impact callouts |
| Bold phrase within sentence | 0 = pre-phrase, 1 = bold phrase, 2+ = continuation | `ALSAP ensures ` + `ongoing safety surveillance` + ` across...` |

When a paragraph rewrite changes content that spans multiple runs, set
`run_index: 0` to the full new text and add additional entries with
`new_text: ""` to clear the residual runs (runs 1, 2, 3, etc.).

---

## Segment index guidance (how to target multi-row elements)

Elements with formatted multi-paragraph content are split across multiple
rows in the matrix, all sharing the same element ID. The first row is
`segment_index: 0`; subsequent rows increment.

To find the correct segment index for a given element: count the rows
sharing the same ID in the matrix, in order from top to bottom, starting
at 0.

---

## Validation rules

A manifest is valid if:

1. `meta` contains all required fields.
2. Every change entry contains all required fields.
3. `disposition` is one of the five defined values.
4. `segment_index` and `run_index` are non-negative integers.
5. `new_text` is a string (empty string is valid).
6. `id` values are non-empty strings.
7. The JSON is well-formed with no trailing commas.

`sl_apply.py` will exit with a non-zero status if any `REVISE` entry
targets an ID not found in the matrix, or a `segment_index` or
`run_index` out of range.

---

## Example entry — simple single-run replacement

```json
{
  "id":            "r2Sza7KD5kGu4ujb3ahuxA",
  "slide":         "600_100",
  "element_type":  "BUT 2 - Normal state",
  "disposition":   "REVISE",
  "reviewer":      "Irene Baumgart",
  "canon_basis":   "SOP-AST-29080 contributor roles use 'Clinical Safety / PV' terminology.",
  "segment_index": 0,
  "run_index":     0,
  "new_text":      "PV Safety",
  "notes":         "Bold preserved.",
  "source_comment": "Please update 'Drug Safety' with 'PV Safety'",
  "review_flag":   false
}
```

## Example entry — bold label preserved, description changed

```json
{
  "id":            "Uu0F2X1WR02+ZbAuywaxoA",
  "slide":         "SCE500_100",
  "element_type":  "Text Box 3",
  "disposition":   "REVISE",
  "reviewer":      "Irene Baumgart",
  "canon_basis":   "SOP-AST-29080 Section 5: SMT provides safety evaluation and governance, not only strategic oversight.",
  "segment_index": 0,
  "run_index":     1,
  "new_text":      "cross-functional safety evaluation and governance body; reviews blinded aggregate data and ALSAP outputs.",
  "notes":         "Run 0 ('SMT (Safety Management Team): ', bold) left untouched.",
  "source_comment": "The SMT does not only do strategic oversight.",
  "review_flag":   true
}
```

## Example entry set — paragraph rewrite clearing multiple runs

```json
[
  {
    "id":            "EYN7I88P+kacBgnMTXKE/g",
    "slide":         "SCE200_100",
    "element_type":  "TEXT",
    "disposition":   "REVISE",
    "reviewer":      "Irene Baumgart",
    "canon_basis":   "SOP-AST-29080: ALSAP complements existing governance. SMTs conducted cross-trial review; ALSAP standardizes it.",
    "segment_index": 0,
    "run_index":     0,
    "new_text":      "When we develop a new drug, we typically run multiple clinical trials at the same time. Safety data accumulates across all of these trials, and while cross-trial review has long been part of Safety Management Team activity, it has lacked a systematic, asset-level framework. ALSAP addresses that need.",
    "notes":         "Full paragraph rewrite. Runs 1-3 cleared below.",
    "source_comment": "This statement does not reflect current state. SMTs have monitored cross-trial safety.",
    "review_flag":   true
  },
  {
    "id":            "EYN7I88P+kacBgnMTXKE/g",
    "slide":         "SCE200_100",
    "element_type":  "TEXT",
    "disposition":   "REVISE",
    "reviewer":      "Irene Baumgart",
    "canon_basis":   "Residual run cleared after paragraph rewrite.",
    "segment_index": 0,
    "run_index":     1,
    "new_text":      "",
    "notes":         "Clears bold run.",
    "source_comment": "",
    "review_flag":   false
  }
]
```

---

## Non-text changes — record but do not execute

Comments about interactions, visuals, transitions, or Storyline
development tasks cannot be addressed via the translation matrix.
They must still be recorded in the manifest with an appropriate
non-REVISE disposition so they appear in the audit log.

```json
{
  "id":            "",
  "slide":         "INTRO_SCE4_ALSAPotherProcesses",
  "element_type":  "Slide behavior",
  "disposition":   "DEV_FIX",
  "reviewer":      "Alan Fu",
  "canon_basis":   "",
  "segment_index": 0,
  "run_index":     0,
  "new_text":      "",
  "notes":         "Title slide auto-advances; should require click like other section title slides.",
  "source_comment": "This title slide automatically proceeds to the next slide, unlike previous title slides.",
  "review_flag":   false
}
```
