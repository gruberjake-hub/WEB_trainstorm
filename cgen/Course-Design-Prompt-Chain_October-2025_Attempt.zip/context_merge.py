#!/usr/bin/env python3
# ------------------------------------------------------------
# context_merge.py
#
# WHAT THIS IS:
#   A tiny, deterministic merger for "context shards" produced by your
#   Context_Classifier step. It resolves three artifacts:
#     1) context_org.json
#     2) context_curriculum/<slug>.json
#     3) context_course/<slug>.json
#   and a fourth diagnostic file:
#     4) context_collisions.json
#
# WHY THIS EXISTS:
#   To avoid relying on an LLM to merge. This script enforces your precise
#   precedence rules and dedup logic, so builds are reproducible and auditable.
#
# PRECEDENCE RULES (applied in this order):
#   1) Higher merge.priority wins (0–100)
#   2) Newer merge.recency (ISO date) wins
#   3) More specific scope wins: module > course > curriculum > dept > org
#   4) If still tied, keep first encountered (stable sort) and log a tie
#
# EXPIRY:
#   A shard is expired if today > (recency + ttl_days). Expired shards are
#   excluded and listed under collisions["expired"].
#
# FIELD MERGE STRATEGY:
#   - Scalars/objects like profile/style/audience/media/legal: winner-takes-all
#     per top-level slot (we don't deep-merge subkeys to keep it deterministic).
#   - Arrays of objects with stable keys are deduped:
#       policies -> key "name" (case-insensitive)
#       terminology -> key "term"
#       systems -> key "name"
#     If two items share a key, precedence decides the winner and the loser is
#     recorded in collisions["replacements"].
#   - Arrays of strings (e.g., style.tone, media.templates) are unioned unique
#     unless a shard marks the slot authoritative via merge.authoritative=true
#
# INPUT:
#   JSON array of shards from Context_Classifier (see your prompt schema).
#
# OUTPUT:
#   Writes JSON files to --outdir and prints a tiny summary to stdout.
#
# ------------------------------------------------------------

import argparse, json, os, sys
from datetime import date, datetime, timedelta

SPECIFICITY_RANK = {"org":0, "dept":1, "curriculum":2, "course":3, "module":4}

TOP_SLOTS = ["profile","style","audience","media","legal","examples"]  # winner-takes-all per slot
ARRAY_SLOTS = {
    "policies": "name",
    "terminology": "term",
    "systems": "name",
}

def parse_date(d):
    # Accepts "YYYY-MM-DD" or ISO 8601; returns date object or None
    if not d:
        return None
    try:
        return datetime.fromisoformat(d.replace("Z","")).date()
    except Exception:
        try:
            return datetime.strptime(d[:10], "%Y-%m-%d").date()
        except Exception:
            return None

def is_expired(shard, today):
    recency = parse_date(shard.get("merge",{}).get("recency"))
    ttl = shard.get("merge",{}).get("ttl_days", 0) or 0
    if recency is None:
        return False  # if no recency, treat as non-expiring (conservative)
    return today > (recency + timedelta(days=int(ttl)))

def precedence_key(shard):
    m = shard.get("merge",{})
    scope = shard.get("meta",{}).get("scope","org")
    # Sort descending by priority, recency, specificity
    priority = int(m.get("priority",0))
    recency = parse_date(m.get("recency")) or date.min
    spec = SPECIFICITY_RANK.get(scope,0)
    # Python sorts ascending; invert by using negatives where needed
    return (-priority, -(recency.toordinal()), -spec)

def ensure_base_context(target, target_id):
    return {
        "meta": {
            "target": target,
            "id": target_id,
            "generated_at": datetime.utcnow().isoformat() + "Z",
            "source_counts": {
                "input_shards": 0, "used_shards": 0,
                "expired_shards": 0, "collisions": 0
            }
        },
        "profile": {},
        "style": {},
        "audience": {},
        "policies": [],
        "terminology": [],
        "systems": [],
        "examples": {"good": [], "bad": []},
        "media": {},
        "legal": {},
        "merge_trace": []
    }

def overlay_slot_winner(ctx, slot_name, winner_shard, losers, collisions):
    # Winner-takes-all for top-level object slot
    before = json.dumps(ctx.get(slot_name, {}), sort_keys=True)
    candidate = winner_shard.get(slot_name, {})
    if candidate:
        ctx[slot_name] = candidate
        # Log losers if any had the same slot populated
        losing_meta = []
        for ls in losers:
            if ls.get(slot_name):
                losing_meta.append({
                    "scope": ls["meta"].get("scope"),
                    "priority": ls["merge"].get("priority"),
                    "recency": ls["merge"].get("recency"),
                    "source": (ls.get("merge",{}).get("source_refs") or [{}])[0].get("file")
                })
        if losing_meta:
            ctx["merge_trace"].append({
                "field": slot_name,
                "winner": {
                    "scope": winner_shard["meta"].get("scope"),
                    "priority": winner_shard["merge"].get("priority"),
                    "recency": winner_shard["merge"].get("recency"),
                    "source": (winner_shard.get("merge",{}).get("source_refs") or [{}])[0].get("file")
                },
                "losers": losing_meta
            })
            collisions["replacements"].append({
                "field": slot_name,
                "winner": {"scope": winner_shard["meta"].get("scope"),
                           "priority": winner_shard["merge"].get("priority"),
                           "recency": winner_shard["merge"].get("recency")},
                "loser_count": len(losing_meta),
                "reason": "precedence"
            })
    after = json.dumps(ctx.get(slot_name, {}), sort_keys=True)
    return before != after

def merge_array_objects(ctx, slot_name, shards_sorted, key_field, collisions):
    # Deduplicate by key_field using shard precedence
    # Build current index from ctx
    items = ctx.get(slot_name, []) or []
    index = {}
    for it in items:
        k = (it.get(key_field) or "").strip().lower()
        if k: index[k] = {"item": it, "from": None}  # unknown origin

    for shard in shards_sorted:
        for it in shard.get(slot_name, []) or []:
            k = (it.get(key_field) or "").strip().lower()
            if not k:
                continue
            if k not in index:
                index[k] = {"item": it, "from": shard}
            else:
                # Existing entry competes; precedence already encoded by sort order,
                # so existing 'index[k]' wins; this one loses -> log replacement
                collisions["replacements"].append({
                    "field": f"{slot_name}.{it.get(key_field)}",
                    "winner": {"scope": index[k]["from"]["meta"]["scope"]} if index[k]["from"] else {"scope":"unknown"},
                    "loser": {"scope": shard["meta"]["scope"]},
                    "reason": "precedence"
                })
    # Write back in stable name order
    ctx[slot_name] = sorted([v["item"] for v in index.values()],
                            key=lambda x: (x.get(key_field) or "").lower())

def union_string_arrays(ctx, path_list, shards_sorted, collisions):
    # Supports paths like ["style","tone"] or ["examples","good"]
    # Merge unique strings unless any shard sets merge.authoritative for that path.
    authoritative = False
    values = set()
    # Seed with existing
    slot = ctx
    for p in path_list[:-1]:
        slot = slot.setdefault(p, {})
    arr_name = path_list[-1]
    seed = slot.get(arr_name, []) or []
    for s in seed: values.add(str(s))

    # Scan shards
    for shard in shards_sorted:
        # Authoritative flag lives in shard["merge"]["authoritative_paths"] as a list of dotpaths (optional convention)
        auth_paths = shard.get("merge", {}).get("authoritative_paths", []) or []
        dot = ".".join(path_list)
        if dot in auth_paths:
            authoritative = True
            values = set()  # reset
        # Consume candidate array if present
        source = shard
        slot2 = source
        for p in path_list[:-1]:
            slot2 = slot2.get(p, {})
        arr = slot2.get(arr_name, None)
        if isinstance(arr, list):
            for s in arr:
                values.add(str(s))

    # Write back
    slot[arr_name] = sorted(values)
    if authoritative:
        collisions["authoritative_overrides"].append({"field": ".".join(path_list), "note":"authoritative override"})

def resolve_target(shards, target, target_id, scope_union, today, collisions):
    """
    scope_union: iterable of scopes to include for this target (e.g., ["org"])
                 or ["org","dept","curriculum"] for curriculum, etc.
    """
    ctx = ensure_base_context(target, target_id)
    relevant = [s for s in shards if s.get("meta",{}).get("scope") in scope_union]
    ctx["meta"]["source_counts"]["input_shards"] = len(relevant)

    # Filter expired
    active, expired = [], []
    for s in relevant:
        (expired if is_expired(s,today) else active).append(s)
    ctx["meta"]["source_counts"]["expired_shards"] = len(expired)
    for s in expired:
        collisions["expired"].append({
            "id": s.get("meta",{}).get("id"),
            "scope": s.get("meta",{}).get("scope"),
            "recency": s.get("merge",{}).get("recency"),
            "ttl_days": s.get("merge",{}).get("ttl_days")
        })

    # Sort by precedence (highest first)
    active_sorted = sorted(active, key=precedence_key)

    # Winner-takes-all for top-level object slots
    for slot in TOP_SLOTS:
        # Find first shard that has this slot populated
        winners = [s for s in active_sorted if s.get(slot)]
        if winners:
            winner = winners[0]
            losers = winners[1:]
            overlay_slot_winner(ctx, slot, winner, losers, collisions)

    # Array-of-objects slots with keyed dedupe
    for slot, key_field in ARRAY_SLOTS.items():
        merge_array_objects(ctx, slot, active_sorted, key_field, collisions)

    # String-array unions with optional authoritative override examples
    union_string_arrays(ctx, ["style","tone"], active_sorted, collisions)
    union_string_arrays(ctx, ["media","templates"], active_sorted, collisions)
    union_string_arrays(ctx, ["examples","good"], active_sorted, collisions)
    union_string_arrays(ctx, ["examples","bad"], active_sorted, collisions)

    ctx["meta"]["source_counts"]["used_shards"] = len(active_sorted)
    # collisions count (rough heuristic = total logged items)
    ctx["meta"]["source_counts"]["collisions"] = sum(len(v) for v in collisions.values())
    return ctx

def main():
    ap = argparse.ArgumentParser(description="Merge context shards into resolved context files.")
    ap.add_argument("--shards", required=True, help="Path to shards.json (array from Context_Classifier)")
    ap.add_argument("--org-id", required=True, help="Identifier for org target (e.g., company-default)")
    ap.add_argument("--curriculum", required=True, help="Curriculum slug")
    ap.add_argument("--course", required=True, help="Course slug")
    ap.add_argument("--outdir", required=True, help="Output directory (e.g., _BUILD)")
    args = ap.parse_args()

    os.makedirs(args.outdir, exist_ok=True)
    with open(args.shards, "r", encoding="utf-8") as f:
        shards = json.load(f)
        if not isinstance(shards, list):
            print("ERROR: shards must be a JSON array.", file=sys.stderr); sys.exit(1)

    today = date.today()
    collisions = {"expired": [], "replacements": [], "ties": [], "authoritative_overrides": []}

    # Targets:
    org_ctx = resolve_target(shards, "org", args.org_id, ["org"], today, collisions)
    cur_ctx = resolve_target(shards, "curriculum", args.curriculum, ["org","dept","curriculum"], today, collisions)
    crs_ctx = resolve_target(shards, "course", args.course, ["org","dept","curriculum","course","module"], today, collisions)

    # Write files
    org_path = os.path.join(args.outdir, "context_org.json")
    cur_dir = os.path.join(args.outdir, "context_curriculum")
    crs_dir = os.path.join(args.outdir, "context_course")
    os.makedirs(cur_dir, exist_ok=True)
    os.makedirs(crs_dir, exist_ok=True)
    cur_path = os.path.join(cur_dir, f"{args.curriculum}.json")
    crs_path = os.path.join(crs_dir, f"{args.course}.json")
    col_path = os.path.join(args.outdir, "context_collisions.json")

    for p, obj in [(org_path, org_ctx), (cur_path, cur_ctx), (crs_path, crs_ctx), (col_path, collisions)]:
        with open(p, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2)

    print("Wrote:")
    print(" -", org_path)
    print(" -", cur_path)
    print(" -", crs_path)
    print(" -", col_path)

if __name__ == "__main__":
    main()
