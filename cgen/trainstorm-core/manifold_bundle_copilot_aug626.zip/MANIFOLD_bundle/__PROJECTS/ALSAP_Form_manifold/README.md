# FORM-AST-34037 + SOP-AST-29080 ALSAP Manifold JSON Package

Package version: 0.1.0-draft  
Created UTC: 2026-08-06T14:31:19Z  
Status: Draft for SME review

## Modeling Principle

Model first. Overlay second. Render third. Do not turn the SOP, form, or rendered guide into duplicate sources of truth.

## Primary Relationship Finding

SOP-AST-29080 governs FORM-AST-34037. FORM-AST-34037 operationalizes a core part of SOP-AST-29080 by providing the ALSAP template used to draft the asset-level ALSAP.

## Files

- `00_package_manifest.json` - package metadata and source mapping
- `01_source_inventory.json` - artifact inventory and relationship finding
- `02_process_model.sop-ast-29080.json` - canonical SOP process model
- `03_form_model.form-ast-34037.json` - canonical form/template model
- `04_crosswalk.sop-form.json` - SOP-to-form relationship map
- `05_guidance_overlay.json` - semantic guidance overlay
- `06_review_matrices.json` - SME-friendly review structures
- `07_render_profiles.json` - recommended downstream render profiles
- `alsap_manifold_combined.json` - all package content in one file

## Source References

- SOP-AST-29080 source reference: `turn1search1`
- FORM-AST-34037 source reference: `turn1search2`

## Recommended Next Step

Use this package to render the SME Review Workbook first, then the interactive HTML ALSAP Field Guide.
