﻿# Quickstart

1. Upload source artifact.
2. Run intake prompt.
3. Generate canonical model.
4. Generate overlay.
5. Review with SMEs.
6. Generate render.

