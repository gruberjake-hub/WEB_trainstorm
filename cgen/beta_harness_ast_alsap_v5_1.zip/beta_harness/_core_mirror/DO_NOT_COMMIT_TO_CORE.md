# _core_mirror — READ THIS

These three files are **byte-for-byte mirrors** of canonical files that live in the repo at
`cgen/trainstorm-core/`:

| here | canonical home |
|---|---|
| `atom.schema.json` | `cgen/trainstorm-core/schemas/atom.schema.json` |
| `procedure.facet.schema.json` | `cgen/trainstorm-core/schemas/procedure.facet.schema.json` |
| `procedure.enum.json` | `cgen/trainstorm-core/vocab/procedure.enum.json` |

They exist here **only** so the harness can run standalone (outside a repo checkout). They are **not
canonical**.

## Rules
- **Never commit these over `cgen/trainstorm-core/`.** That is exactly the mistake that happened in
  commit `c6ad256` (a thin vendored `atom.schema.json` and a flat `procedure.enum.json` overwrote the
  real ones; restored from `0bc0097` / `05211ed`).
- Sync direction is **one-way: copy FROM core INTO here**, never the reverse.
- When running the tools inside the repo, pass `--core-dir <path>/cgen/trainstorm-core` so they read
  the **real** files and ignore this mirror entirely. Without `--core-dir`, `validate_atoms.py` prints
  a WARNING and falls back to this mirror.

The deeper lesson (the manifold's own invariant): a canonical source must have exactly one home.
A second, editable copy is a drift vector the moment it's reachable — which is why these are quarantined
behind a directory named so you can't forget.
