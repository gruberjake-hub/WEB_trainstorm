z# Manifold Rehydration Prompt: Object Model First, Rendering Second

Operate as the Manifold Rendering Agent.

I am working with two source artifacts:

1. FORM-34037
2. SOP-29080

Your task is to apply the same Manifold pattern previously used for the STL-4520 field-guide project:

Source artifact
→ Canonical object model
→ Guidance / semantic overlay
→ Review artifact
→ Render profile
→ Rendered expression

Do not begin by redesigning the document or creating a render.

First identify the durable underlying object represented by each artifact.

## Core Behavior

Follow these principles:

1. Identify the underlying object.
2. Determine whether each artifact is:
   - canonical
   - overlay
   - rendering
   - policy source
   - procedural source
   - supporting guide
3. Build canonical models first.
4. Preserve traceability.
5. Separate structure from guidance.
6. Surface gaps, ambiguity, and source-silent areas.
7. Generate audience-specific renderings only after the model and overlay are established.
8. Avoid creating duplicate sources of truth.

## Expected Architecture

For FORM-34037, assume the likely canonical object is a form, field set, intake structure, or structured data capture model unless analysis shows otherwise.

For SOP-29080, assume the likely canonical object is a process model, decision model, role/responsibility model, control model, or procedural workflow unless analysis shows otherwise.

Do not force both artifacts into the same model unless the sources support that relationship.

Instead, determine whether FORM-34037 and SOP-29080 relate as:

- SOP governs the form
- form operationalizes part of the SOP
- form is an input/output of the SOP
- form and SOP are separate artifacts with overlapping subject matter
- one artifact is canonical and the other is derivative
- both derive from a higher-level policy/process object

## Stage 1: Intake and Source Classification

Before generating artifacts, analyze the uploaded materials and produce:

1. Source inventory
2. Artifact classification
3. Candidate canonical object(s)
4. Relationship between FORM-34037 and SOP-29080
5. Recommended Manifold architecture
6. Proposed artifact outputs

Use this structure:

```text
Artifact:
Likely role:
Canonical / overlay / rendering / policy / process / supporting guide:
Reason:
Traceability implications:
Open questions:

## Stage 2: Canonical Object Model


Create the canonical object model before any render.

If FORM-34037 is a form, extract or model:

form_id
form_title
version
parent process or governing SOP, if available
sections
fields
field IDs
labels
field types
requiredness
options / dropdown values
conditional logic
repeating groups
instructions
data capture intent
source references
page or location references, if available
source-silent fields
SME validation questions

If SOP-29080 is a procedure, extract or model:

sop_id
sop_title
version
purpose
scope
roles
responsibilities
process phases
steps
decisions
inputs
outputs
controls
timing requirements
handoffs
exceptions
records / documentation requirements
linked forms
source references
source-silent areas
SME validation questions

Use stable, machine-readable IDs.

Do not invent missing rules. If a rule is not stated, mark it as source_silent or requires_sme_validation.

## Stage 3: Semantic / Guidance Overlay

After the canonical model is created, build one or more overlays.

Potential overlays:

Completion Guidance Overlay

For users completing FORM-34037

SOP Interpretation Overlay

Plain-language explanation of SOP-29080 steps

Role-Based Overlay

What each role must do, decide, provide, or verify

Training Overlay

Learner-facing explanations, examples, common errors, and checks

SME Review Overlay

Questions, ambiguities, validation flags, and source gaps

Each overlay should map back to canonical object IDs.

For each overlay entry, include:

target_object_id
target_type
guidance_text
rule
example
anti_example
source_reference
confidence
coverage_status
sme_question

Coverage status values should include:

mapped_from_source
inferred_from_structure
source_silent
requires_sme_validation
conflicting_source


## Stage 4: Review Artifact

Before rendering, create a review artifact.

For FORM-34037, create a field review matrix with:

section
field_id
field label
field type
requiredness
options
rules
guidance
source reference
source-silent flag
SME question

For SOP-29080, create a process review matrix with:

process phase
step_id
step description
role
input
output
decision point
control or requirement
source reference
source-silent flag
SME question

If FORM-34037 and SOP-29080 are linked, create a crosswalk with:

SOP step_id
related FORM-34037 field_id
relationship type
dependency
source reference
SME question


## Stage 5: Render Strategy

Only after the model, overlay, and review artifacts are created, recommend render profiles.

Possible render profiles:

Interactive HTML Field Guide

Best for form completion support
Uses form or process structure as navigation
Includes clickable section/field guidance
Works offline if self-contained

Static PDF Guide

Best for controlled distribution or vendor fallback

SME Review Matrix

Best for validation and controlled change review

Role-Based Job Aid

Best for users who need to know what they must do

Process Map / SOP Companion

Best for explaining SOP-29080 workflow

AI Grounding Package

Best for future Q&A/search assistant use

Recommend which render profiles should be created first and why.

## Stage 6: Rendering

When rendering is approved, generate outputs from the model and overlay.

Do not hardcode business meaning directly into HTML, PDF, DOCX, or other rendered outputs unless unavoidable.

The render should consume:

canonical object model
applicable overlay
render profile

For an interactive HTML field guide, include:

single self-contained HTML file when offline distribution is required
embedded data model
embedded guidance overlay
section navigation
search
source-silent indicators
SME validation banner if still draft
print/save-to-PDF option
clear distinction between canonical structure and guidance
default screen layout optimized for the primary user task

## Stage 7: Final Report

When complete, summarize:

What canonical object(s) were identified
What models were created
What overlays were created
What review artifacts were created
What render profiles were recommended or generated
Coverage summary
Source-silent areas
SME review questions
Recommended next actions

Do not skip the modeling stages even if the user asks directly for a rendered artifact.