# Decision log — Course Engine / Manifold

*Running log of settled architectural decisions. Newest first. One entry = one decision that is
closed enough to build on; if it reopens, add a new dated entry rather than editing history.*

## 2026-08-10 — Ingest/headwater agent architecture is settled; next rung is the prompt pass

The ingest/decomposition agent is **not** greenfield — it is the **headwater authoring agent**
(`procedure-object-model.md`), now extended to a second source type via the **`form` facet**
(`form-object-model.md`, gated 11/11). Procedure and form are duals on one spine; the object-model
(process_model / form_model) is an **ingest view**, not the output-of-record (the atoms are). Facet
ownership is single-writer: this agent owns `meaning`, `object`, and the source-type facet
(`procedure` | `form`); intent / expression / audience / render are downstream readers. **Next real
rung: the prompt pass** — write the headwater agent's system + intake prompts against this settled
architecture, harvesting the bundle's prompts as raw material. Open items carried: mint 3 registry
seeds (`role_alsap_lead`, `rec_alsap`, `reg_benefit_risk_profile`); resolve the Benefit-Risk
controlled-vs-example SME question.

# Decision log — Course Engine / Manifold

*Running log of settled architectural decisions. Newest first. One entry = one decision that is
closed enough to build on; if it reopens, add a new dated entry rather than editing history.*

## 2026-08-12 — Carry: no owner yet for the authored affective / narrative arc (supra-atomic composition)

Surfaced by Jake's "is this too atomic?" check (use case: a course with a heavy learner-psychological
mapping component). Verdict: the design is **atomic, not atomist** — atoms carry relations (graph, not
chain), *containers are atoms too* so group-level properties bind to the container node (a section's
intensity ramp lives on the Section atom), and shared **closed registries** keep independent per-atom
style choices coherent. So the gestalt is not generally lost.

**The genuine gap it exposed:** psychological/narrative structure that is emergent across
**non-containment** relations — a callback (scene 2 → scene 40), a fear planted early / resolved late, a
recurring motif, a difficulty ramp spanning modules — has *no facet and no agent owner* today. `object`
owns structural relations, `intent` owns objective prerequisites, but the **authored affective/narrative
arc** as a first-class relation is homeless.

The clarifying split:
- **Authored arc** — the emotional/narrative structure the *designer* builds, independent of any learner.
  Content, supra-atomic, currently homeless. Near-term-ish; wants its **own clean pass** — do NOT graft it
  onto another agent's turn. Candidate: a new single-writer facet (working name `affect` / `narrative_arc`)
  bound to **container atoms** for containment and to **typed edges** for cross-cutting relations.
- **Per-learner psychological adaptation** — mapping to *this* learner's motivation/mastery/affect. That
  is the `audience` facet + the **Response Engine** (Chameleon's stub). Frontier, walled off, PII-free on
  the content side.

**Shape of the fix (keeps the philosophy):** make the arc **first-class** — a node or governed typed
relation, single-writer, keyed by IDs; atomic in the good sense (governed, inspectable, reusable), not
atomist. **Anti-pattern to avoid:** letting the arc live only in a render agent's runtime (emergent at
draw time, written nowhere) — that smuggles a supra-atomic truth outside the graph, the exact drift the
manifold exists to kill.

Status: **carry.** Sibling to the deferred ROI/goal node above objectives (same "real gap, cleanly
nameable" character).

## 2026-08-11 — Facet-owner spine adopted; Headwater re-expressed on it

Agent system prompts are now built as **spine + specialization**. `agents/_shared/facet_owner_spine.md`
holds the shared ~70% of every facet owner's contract (single-writer, wake-on-graph-state, vocab
governance, provenance + `source_hash` staleness, no-PII, uncertainty-surfacing, operating loop, drift
checks). Each agent is a small specialization that fills **seven slots**: name, one-line role, the facet
it writes + keys, wake condition, governed vocab refs, modes, schema refs. The spine is canonical and
referenced, never pasted into each agent (reference-don't-embed, applied to the prompts themselves).

- **Load-bearing generalization:** Headwater owns `content_hash` (hash of `meaning`). Every *other* facet
  owner records the `source_hash` it bound against, so "is this facet stale?" is one graph walk.
- **The one exception, documented not smuggled:** Headwater is the *origin writer* — it writes three
  things at birth (`meaning` + `object` + source-type). Single-writer is a rule *per facet*; each of the
  three still has exactly one writer. Every downstream owner writes exactly one facet.
- **Headwater modes settled and written into its prompt:** `direct` (bounded artifact → mint only) and
  `case_author` (large corpus → scope-commit → *durable committed-design artifact* → mint; the mint wakes
  on the artifact, is not handed anything). A lightweight **router** (haiku-class, writes nothing to the
  graph, emits a governed route label) is the single operator-facing front door that selects the mode.
- Files: `agents/_shared/facet_owner_spine.md`; `agents/headwater_ingest/02_system_prompts/core_agent/system_prompt.md` (v0.2-on-spine).

### Agent batch progress (rolling, under this spine)
- **Cartographer** (intent facet) — built, read-then-bind, no loop override needed; also maintains the
  objective ontology as its governed vocabulary. `agents/cartographer/…`.
- **Couturier** (expression · *style* sub-facet) — built. Proves the **sub-facet single-writer split**:
  `expression` has two writers divided **by key** — Couturier owns style keys (`style_ref`,
  text/motion/layout/interaction primitives, `content_type`, `visual_type`); Dragoman owns locale keys
  (locale packs, `term_refs`/glossary). Single-writer holds at *key* granularity. `agents/couturier/…`.
- **Dragoman** (expression · *locale* sub-facet — AST009, the one real agent), **Griot** (narration),
  **Chameleon** (audience — frontier stub) — pending.

## 2026-08-12 — Objectives ontology instantiated + STRUCTURE.md reconciled

The intent ontology is no longer a dangling design. Built and gated 7/7:
- `schemas/objectives.schema.json` — objective-store contract. Governed like the roles/records registries
  (`closed_list: true`, `obj_` prefix enforced, ungoverned ids rejected); grown only by entry + version
  bump. The schema currently **rejects** a `serves` field, so adding the (still un-designed) ROI/goal
  upward link later is a deliberate version bump, not accidental drift.
- `ontology/objectives.json` — seeded with only the objectives canon already names (`obj_recognize_psi`
  from atom-spec §4, plus `obj_define_psi` added as the root the example required but nothing defined —
  fixing a latent dangling prerequisite). Both `status: example`, provenance stamped.
- Validator checks: schema valid Draft 2020-12; seed validates; every `requires[]` resolves; prereq graph
  acyclic; and the negative controls (dangling ref, ungoverned id, premature `serves`) are all rejected.
- **STRUCTURE.md reconciled** (4 edits, byte-clean): `ontology/` added to the tree (beside `registry/` +
  `locales/`), a matching rule-table row, `objectives.schema.json` in the schemas block, and `ontology/*.json`
  added to the SYNC list. The `obj_` prefix was already governed there — the only real gap was the folder.
- **Per-project note:** the objective *schema* is shared core; an objective *instance* (e.g. Astellas PV)
  is per-project content. The shared-core / per-project line runs through the instance stores — a known
  thread (same as the Astellas glossary/corpus classification).

## 2026-08-11 — Deferred: prompt resolver + plain-language explainer (explainer = auto-dogfood candidate)

The spine + specialization split is DRY and machine-facing but adds indirection between a reviewer and
"the prompt itself." Two human-facing **projections** were identified to close that gap. Both deferred,
for different reasons. Discipline for both: one canonical source (spine + specialization); the projection
is *derived*, never authored directly — the same "deterministic projection of an engineering source of
truth" the content model already uses (atom store → controlled Word/PDF). Embedding/inlining is forbidden
in the source but fine in a projection (derived + disposable).

1. **Prompt resolver (compiler).** A small deterministic script that walks `agents/`, fills each agent's
   slots into the spine, and emits a fully-inlined `resolved_prompt.md` per agent. Render-only, never
   hand-edited — edit the spine/specialization and re-render. Cheap, buildable anytime, doubles as a build
   sanity-check. Deferred only because it is not on the path to building the agents. **Pick up whenever.**

2. **Plain-language explainer.** A further, *simplified* projection that translates an agent's rules into
   SME/stakeholder English. Lossy, audience-specific. **Best built as auto-dogfood, not by hand:** once the
   projection/render path exists, feed the manifold's own architecture + prompts in as a corpus (Headwater,
   Case-Author mode) → atoms → a plain-language projection. Deferring is the *right* call, not just triage —
   hand-built now vs. a near-free projection later, and it doubles as an end-to-end self-test on a corpus
   we understand completely. **Revisit after the projection/render path exists.**

## 2026-08-10 — Agent package folder structure locked (v0.1, "for now")

The numbered scaffold from the bundle's `Manifold_Rendering_Agent` is adopted as the standard
**agent operating-package** layout. Each agent folder gets:

```
<agent>/
  README.md
  01_operating_model/
  02_system_prompts/
    core_agent/
    modes/field_guide_mode/
  03_user_prompts/
    model_build_meta-mode/
    quick_starts/
  04_schemas/            # POINTERS to canon + agent-local operating schemas ONLY — see caveat
    canonical_models/
    overlays/
    render_profiles/
  05_modes/field_guide_mode/examples/
  07_examples/<worked_example>/
  08_governance/validation_checklists/
  09_team_guidance/how_to_run/
```

**Caveat (invariant guard):** canonical schemas and vocabularies do **not** get copied into an agent's
`04_schemas/`. They have one home — `cgen/trainstorm-core/schemas/` and `/vocab/`. Putting a copy in the
agent folder would spawn a second, drifting source of truth. `04_schemas/` holds *references* to the
canon schemas plus any agent-local operating schema (e.g. a render-profile config the agent alone uses).

**Where current artifacts land:**
- Headwater Ingest Agent core system prompt → `agents/headwater_ingest/02_system_prompts/core_agent/system_prompt.md`
- `form.facet.schema.json`, `vocab/form.enum.json` → **`cgen/trainstorm-core/`** (canon), *not* the agent's `04_schemas/`.

**Still open ("for now"):** `06` and `10` are unassigned; normalize the range when their contents are known.

## 2026-08-10 — Ingest/headwater agent architecture is settled; next rung is the prompt pass

The ingest/decomposition agent is **not** greenfield — it is the **headwater authoring agent**
(`procedure-object-model.md`), now extended to a second source type via the **`form` facet**
(`form-object-model.md`, gated 11/11). Procedure and form are duals on one spine; the object-model
(process_model / form_model) is an **ingest view**, not the output-of-record (the atoms are). Facet
ownership is single-writer: this agent owns `meaning`, `object`, and the source-type facet
(`procedure` | `form`); intent / expression / audience / render are downstream readers. **Next real
rung: the prompt pass** — write the headwater agent's system + intake prompts against this settled
architecture, harvesting the bundle's prompts as raw material. Open items carried: mint 3 registry
seeds (`role_alsap_lead`, `rec_alsap`, `reg_benefit_risk_profile`); resolve the Benefit-Risk
controlled-vs-example SME question.
