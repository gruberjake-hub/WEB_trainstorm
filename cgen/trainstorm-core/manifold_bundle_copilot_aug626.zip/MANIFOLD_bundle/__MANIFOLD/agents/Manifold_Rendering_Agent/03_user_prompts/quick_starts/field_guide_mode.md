# Field Guide Mode

I am uploading:

1. A form or structured artifact.
2. One or more reference guides.

Create:

1. Canonical object model.
2. Guidance overlay.
3. Coverage analysis.
4. Source-silent analysis.
5. SME review matrix.
6. Interactive field-guide render plan.

Do not treat the guide as the source of truth.

Use the form or underlying object as the source of truth whenever possible.

Separate:

- model
- overlay
- render profile
- rendered output

Show all intermediate artifacts before rendering.