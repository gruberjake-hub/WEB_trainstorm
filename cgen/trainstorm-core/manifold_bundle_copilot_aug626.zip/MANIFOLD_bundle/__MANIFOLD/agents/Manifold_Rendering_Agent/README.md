﻿# Manifold Rendering Agent

Reusable agent architecture for transforming source artifacts into canonical object models, overlays, render profiles, and audience-specific outputs.

