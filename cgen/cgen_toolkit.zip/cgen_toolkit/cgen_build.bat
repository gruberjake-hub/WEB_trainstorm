@echo off
title Trainstorm CGEN - Build Pipeline
color 1F

:: -------------------------------------------------------
:: Locate scripts relative to this bat file
:: -------------------------------------------------------
set "SCRIPTS_DIR=%~dp0scripts"

if not exist "%SCRIPTS_DIR%\file_to_structured_all_md.py" (
    echo.
    echo  [ERROR] Cannot find the CGEN scripts.
    echo  Make sure this file is in the same folder as the
    echo  "scripts" folder that contains the Python files.
    echo.
    pause
    exit /b 1
)

:: -------------------------------------------------------
:: Open Windows folder picker
:: -------------------------------------------------------
echo.
echo  =====================================================
echo   Trainstorm CGEN - Context Builder
echo  =====================================================
echo.
echo  Opening folder selector...
echo  Please choose the project folder you want to process.
echo.

for /f "usebackq delims=" %%I in (`powershell -noprofile -command ^
    "Add-Type -AssemblyName System.Windows.Forms; ^
     $d = New-Object System.Windows.Forms.FolderBrowserDialog; ^
     $d.Description = 'Select the project folder to process'; ^
     $d.RootFolder = [Environment+SpecialFolder]::MyComputer; ^
     $d.ShowNewFolderButton = $false; ^
     if ($d.ShowDialog() -eq 'OK') { $d.SelectedPath } else { 'CANCELLED' }"`) do set "PROJECT_PATH=%%I"

if "%PROJECT_PATH%"=="CANCELLED" (
    echo  No folder selected. Exiting.
    echo.
    pause
    exit /b 0
)

if "%PROJECT_PATH%"=="" (
    echo  [ERROR] No path returned. Exiting.
    pause
    exit /b 1
)

echo  Selected folder:
echo    %PROJECT_PATH%
echo.

:: -------------------------------------------------------
:: Check Python is still available
:: -------------------------------------------------------
python --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python not found. Please run cgen_setup.bat first.
    echo.
    pause
    exit /b 1
)

:: -------------------------------------------------------
:: Step 1: Convert files to structured Markdown
:: -------------------------------------------------------
set "OUTPUT_BASE=%PROJECT_PATH%\output"

echo  -------------------------------------------------------
echo  Step 1 of 2: Converting files to structured Markdown...
echo  -------------------------------------------------------
echo.

python "%SCRIPTS_DIR%\file_to_structured_all_md.py" ^
    --input "%PROJECT_PATH%" ^
    --output "%OUTPUT_BASE%"

if errorlevel 1 (
    echo.
    echo  [ERROR] Step 1 failed. Check the messages above for details.
    echo  Contact Jake if this continues.
    echo.
    pause
    exit /b 1
)

:: -------------------------------------------------------
:: Find the timestamped subfolder Step 1 just created
:: -------------------------------------------------------
for /f "usebackq delims=" %%F in (`powershell -noprofile -command ^
    "Get-ChildItem -Path '%OUTPUT_BASE%' -Directory ^| ^
     Sort-Object LastWriteTime -Descending ^| ^
     Select-Object -First 1 -ExpandProperty FullName"`) do set "TIMESTAMP_DIR=%%F"

if "%TIMESTAMP_DIR%"=="" (
    echo.
    echo  [ERROR] Could not locate the output folder from Step 1.
    echo  The conversion may have found no supported files.
    echo  Check that your project folder contains .pptx, .docx,
    echo  .xlsx, .pdf, .txt, or .md files.
    echo.
    pause
    exit /b 1
)

echo.
echo  Conversion output: %TIMESTAMP_DIR%
echo.

:: -------------------------------------------------------
:: Step 2: Merge into project_context.md
:: -------------------------------------------------------
echo  -------------------------------------------------------
echo  Step 2 of 2: Merging into project_context.md...
echo  -------------------------------------------------------
echo.

python "%SCRIPTS_DIR%\merge_project_context_hardened.py" ^
    --input "%TIMESTAMP_DIR%" ^
    --output "%TIMESTAMP_DIR%" ^
    --no-timestamp

if errorlevel 1 (
    echo.
    echo  [ERROR] Step 2 failed. Check the messages above for details.
    echo.
    pause
    exit /b 1
)

:: -------------------------------------------------------
:: Done
:: -------------------------------------------------------
echo.
echo  =====================================================
echo   Done! Your project context file is ready.
echo.
echo   Location:
echo     %TIMESTAMP_DIR%
echo.
echo   The file you want is:
echo     project_context.md
echo  =====================================================
echo.

:: Offer to open the output folder in Explorer
set /p OPEN_FOLDER= Open output folder now? (Y/N): 
if /i "%OPEN_FOLDER%"=="Y" explorer "%TIMESTAMP_DIR%"

echo.
pause
