@echo off
title Trainstorm Toolkit - Matrix Reinject
color 1F
setlocal

echo.
echo  =====================================================
echo   Trainstorm Toolkit - Translation Matrix Reinject
echo   (Translated Excel  -^>  back into the matrix .docx)
echo  =====================================================
echo.

set "VENV_PY=%~dp0venv\Scripts\python.exe"
set "SCRIPTS_DIR=%~dp0scripts"

if not exist "%VENV_PY%" (
    echo  [ERROR] The private Python environment was not found.
    echo.
    echo  Please run setup.bat first. You only need to do it once.
    echo.
    pause
    exit /b 1
)

if not exist "%SCRIPTS_DIR%\matrix_reinject.py" (
    echo  This tool has not been installed yet.
    echo.
    echo  When you receive matrix_reinject.py, copy it into the
    echo  "scripts" folder next to this file and run this again.
    echo.
    pause
    exit /b 0
)

:: -------------------------------------------------------
:: Pick the ORIGINAL matrix docx, then the translated Excel.
:: The reinjector writes a new copy of the docx -- it never
:: overwrites the original.
:: -------------------------------------------------------
echo  Step 1: choose the ORIGINAL Storyline matrix (.docx).
echo.

for /f "usebackq delims=" %%I in (`"%VENV_PY%" "%SCRIPTS_DIR%\pick_file.py" "Select the ORIGINAL Storyline matrix (.docx)" "docx"`) do set "MATRIX_PATH=%%I"

if "%MATRIX_PATH%"=="CANCELLED" (
    echo  No file selected. Exiting.
    echo.
    pause
    exit /b 0
)

echo  Original matrix:
echo    %MATRIX_PATH%
echo.
echo  Step 2: choose the TRANSLATED Excel file (.xlsx).
echo.

for /f "usebackq delims=" %%I in (`"%VENV_PY%" "%SCRIPTS_DIR%\pick_file.py" "Select the TRANSLATED Excel file (.xlsx)" "xlsx"`) do set "XLSX_PATH=%%I"

if "%XLSX_PATH%"=="CANCELLED" (
    echo  No file selected. Exiting.
    echo.
    pause
    exit /b 0
)

echo  Translated Excel:
echo    %XLSX_PATH%
echo.

:: -------------------------------------------------------
:: Run the reinjector
:: -------------------------------------------------------
echo  Running: venv\Scripts\python.exe scripts\matrix_reinject.py
echo           --matrix "%MATRIX_PATH%"
echo           --translations "%XLSX_PATH%"
echo.

"%VENV_PY%" "%SCRIPTS_DIR%\matrix_reinject.py" ^
    --matrix "%MATRIX_PATH%" ^
    --translations "%XLSX_PATH%"

if errorlevel 1 (
    echo.
    echo  [ERROR] Reinjection failed or was rejected by validation.
    echo  Check the messages above. Contact Jake if this continues.
    echo.
    pause
    exit /b 1
)

echo.
echo  Done. A new translated copy of the matrix was saved next
echo  to the original. The original was not modified. Import the
echo  new copy into Storyline.
echo.
pause
