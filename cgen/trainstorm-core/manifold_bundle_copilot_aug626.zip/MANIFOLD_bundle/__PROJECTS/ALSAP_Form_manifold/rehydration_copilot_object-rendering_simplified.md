# FORM-34037 + SOP-29080 Manifold Rehydration Prompt

Operate as the Manifold Rendering Agent.

I am uploading FORM-34037 and SOP-29080.

Apply the same pattern used for the STL-4520 field-guide work:

1. Build the canonical object model first.
2. Build semantic/guidance overlays second.
3. Produce review artifacts third.
4. Recommend render profiles fourth.
5. Render only after the model and overlay are clear.

## Primary Question

Determine the relationship between FORM-34037 and SOP-29080.

Specifically, identify whether:

- SOP-29080 governs FORM-34037
- FORM-34037 operationalizes part of SOP-29080
- FORM-34037 is an input/output/record within SOP-29080
- both artifacts derive from a higher-level process
- the artifacts are related but not structurally dependent
- the artifacts are unrelated

## Required Outputs

Produce these outputs in order:

### 1. Source Inventory

For each artifact:

- artifact_id
- title
- version
- type
- role in Manifold architecture
- likely canonical status
- source authority
- relationship to other artifacts

### 2. Canonical Object Model Recommendation

Recommend whether this project needs:

- one combined model
- separate form and process models
- a process model with linked form model
- a form model with SOP-derived guidance overlay
- another architecture

Explain why.

### 3. FORM-34037 Canonical Form Model

If FORM-34037 is a form or field-based artifact, model:

- sections
- fields
- field IDs
- labels
- field types
- requiredness
- options
- repeating groups
- conditions
- instructions
- source references
- source-silent fields
- SME questions

### 4. SOP-29080 Canonical Process Model

If SOP-29080 is procedural, model:

- phases
- steps
- decisions
- roles
- responsibilities
- inputs
- outputs
- controls
- records
- linked forms
- timing requirements
- source references
- source-silent areas
- SME questions

### 5. Crosswalk

Create a crosswalk between SOP-29080 and FORM-34037.

Include:

- sop_step_id
- form_field_id or form_section_id
- relationship type
- dependency
- source reference
- uncertainty
- SME question

### 6. Guidance Overlay

Create a guidance overlay that maps explanatory content to:

- form fields
- form sections
- SOP steps
- SOP decisions
- roles
- records

Include:

- guidance text
- rules
- examples
- anti-examples
- source references
- coverage status
- SME questions

### 7. Review Matrix

Create SME-friendly review matrices:

- FORM-34037 field review matrix
- SOP-29080 process review matrix
- FORM/SOP crosswalk matrix

### 8. Render Strategy

Recommend render outputs.

Consider:

- intended audience
- task
- hosting constraints
- offline needs
- governance
- maintenance strategy

Potential outputs:

- interactive HTML field guide
- interactive SOP/process guide
- static PDF
- role-based job aid
- SME review workbook
- AI grounding package

### 9. Render Plan

For each recommended render, specify:

- source model
- overlay used
- audience
- interaction pattern
- output format
- maintenance implications

Important:
Do not begin with rendering.
Do not turn the SOP or the form guide into a duplicate source of truth.
Model first. Overlay second. Render third.