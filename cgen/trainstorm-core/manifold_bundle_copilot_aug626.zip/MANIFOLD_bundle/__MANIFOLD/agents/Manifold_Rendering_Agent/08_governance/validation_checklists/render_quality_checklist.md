﻿# Render Quality Checklist

- Canonical model separated from overlay
- Source-silent gaps preserved
- SME review questions included
- Render uses model/overlay as source of truth

