# Build A New Manifold Mode

I am introducing a new use case.

Analyze:

- user task
- durable object
- overlays
- review requirements
- render targets

Determine whether this use case should become:

- a new mode
- an extension of an existing mode
- a render profile
- an overlay type

Recommend the architecture and explain why.