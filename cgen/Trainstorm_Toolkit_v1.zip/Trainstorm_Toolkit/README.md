# Trainstorm Toolkit

One folder, one setup, many tools. Every tool in this kit runs from its own
private Python environment, so it works the same on every machine — including
machines with messy or multiple Python installs.

---

## Folder Structure

```
Trainstorm_Toolkit\
  setup.bat                ← Run ONCE to build the private environment
  cgen_build.bat           ← Tool 1: build a project context file for AI
  matrix_extract.bat       ← Tool 2: pull a Storyline translation matrix to Excel
  matrix_reinject.bat      ← Tool 3: put translations back into the matrix
  README.md                ← This file
  venv\                    ← Private Python environment (created by setup.bat)
  scripts\
    file_to_structured_all_md.py
    merge_project_context_hardened.py
    matrix_extract.py        (installed separately)
    matrix_reinject.py       (installed separately)
    pick_folder.py
    pick_file.py
    latest_subdir.py
```

---

## First-Time Setup

1. Double-click `setup.bat`
2. Follow the prompts — it builds a private Python environment inside this
   folder (the `venv` folder) and installs everything the tools need into it
3. You only need to do this once

> **Note:** Python must already be installed on your machine.
> If setup says Python was not found, install it from
> [python.org](https://www.python.org/downloads/) and check
> **"Add Python to PATH"** during installation. Then run setup again.

**Why the private environment matters:** after setup, the tools never use
your machine's Python directly. They always run
`venv\Scripts\python.exe` by its full path. This is why the toolkit can't be
broken by other Python installs, updates, or PATH problems — everything it
needs lives inside this folder.

---

## The Tools

### 1. Context Builder (`cgen_build.bat`)
Converts every supported file in a project folder into structured Markdown,
then merges them into a single `project_context.md` ready to paste into an
AI tool like Claude.

Supported inputs: `.pptx` `.docx` `.xlsx` `.xlsm` `.pdf` `.txt` `.md`

Output lands in: `[your project folder]\output\[timestamp]\project_context.md`

### 2. Matrix Extract (`matrix_extract.bat`)
Takes a Storyline translation matrix (.docx export) and produces a clean
Excel file with one row per text segment: an ID column, the source text,
and an empty translation column. That Excel file is what gets translated —
by an AI or a human. The Word file itself is never edited by hand or by AI.

### 3. Matrix Reinject (`matrix_reinject.bat`)
Takes the original matrix .docx plus the translated Excel file, validates
the translations (every ID present, nothing structural changed), and writes
the translated text back into a **new copy** of the matrix — leaving every
table, row, and formatting element exactly as Storyline expects. The
original file is never modified. The new copy imports cleanly into
Storyline.

If validation fails, the tool tells you exactly which rows are the problem
and writes nothing.

---

## How the Launchers Work (worth 60 seconds)

Each `.bat` file does the same simple thing: it shows you the exact Python
command it is about to run, then runs it using the private environment.
For example:

```
Running: venv\Scripts\python.exe scripts\matrix_extract.py --input "C:\...\matrix.docx"
```

That line is a complete, real command — the same thing you would type in a
terminal yourself. The launcher just types it for you. Over time, these are
the commands you'll recognize and eventually run on your own.

---

## Adding New Tools

New capabilities arrive as two files: a `.bat` launcher for this folder and
a `.py` script for the `scripts` folder. Drop them in and double-click. No
new setup is needed — every tool shares the same private environment.

---

## Questions?

Contact Jake.
