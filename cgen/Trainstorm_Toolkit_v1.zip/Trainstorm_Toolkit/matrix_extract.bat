@echo off
title Trainstorm Toolkit - Matrix Extract
color 1F
setlocal

echo.
echo  =====================================================
echo   Trainstorm Toolkit - Translation Matrix Extract
echo   (Storyline matrix .docx  -^>  Excel for translation)
echo  =====================================================
echo.

set "VENV_PY=%~dp0venv\Scripts\python.exe"
set "SCRIPTS_DIR=%~dp0scripts"

if not exist "%VENV_PY%" (
    echo  [ERROR] The private Python environment was not found.
    echo.
    echo  Please run setup.bat first. You only need to do it once.
    echo.
    pause
    exit /b 1
)

if not exist "%SCRIPTS_DIR%\matrix_extract.py" (
    echo  This tool has not been installed yet.
    echo.
    echo  When you receive matrix_extract.py, copy it into the
    echo  "scripts" folder next to this file and run this again.
    echo.
    pause
    exit /b 0
)

:: -------------------------------------------------------
:: Pick the Storyline translation matrix (.docx)
:: -------------------------------------------------------
echo  Opening file selector...
echo  Please choose the Storyline translation matrix (.docx).
echo.

for /f "usebackq delims=" %%I in (`"%VENV_PY%" "%SCRIPTS_DIR%\pick_file.py" "Select the Storyline translation matrix (.docx)" "docx"`) do set "MATRIX_PATH=%%I"

if "%MATRIX_PATH%"=="CANCELLED" (
    echo  No file selected. Exiting.
    echo.
    pause
    exit /b 0
)

if not exist "%MATRIX_PATH%" (
    echo  [ERROR] The selected file does not exist.
    echo.
    pause
    exit /b 1
)

echo  Selected matrix:
echo    %MATRIX_PATH%
echo.

:: -------------------------------------------------------
:: Run the extractor
:: -------------------------------------------------------
echo  Running: venv\Scripts\python.exe scripts\matrix_extract.py
echo           --input "%MATRIX_PATH%"
echo.

"%VENV_PY%" "%SCRIPTS_DIR%\matrix_extract.py" --input "%MATRIX_PATH%"

if errorlevel 1 (
    echo.
    echo  [ERROR] Extraction failed.
    echo  Check the messages above. Contact Jake if this continues.
    echo.
    pause
    exit /b 1
)

echo.
echo  Done. The Excel file for translation was saved next to
echo  the original matrix. Send that file for translation, then
echo  use matrix_reinject.bat to put the results back.
echo.
pause
