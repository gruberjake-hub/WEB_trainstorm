# What Is The Real Object?

I am uploading one or more artifacts.

Before generating anything, identify:

1. The most durable underlying object.
2. Whether each uploaded artifact is:
   - canonical
   - overlay
   - rendering
3. Potential sources of truth.
4. Potential duplicate sources of truth.
5. Recommended Manifold architecture.

Do not generate outputs yet.

First explain:

- the underlying object
- the proposed canonical model
- recommended overlays
- possible render targets

Present recommendations before proceeding.