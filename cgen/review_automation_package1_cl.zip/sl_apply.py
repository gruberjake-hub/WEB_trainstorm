"""
sl_apply.py — Storyline Translation Matrix Apply Script
========================================================
Applies a structured change manifest to a Storyline translation
matrix DOCX, producing a modified file ready for import back into
Articulate Storyline.

Usage
-----
    # Dry run (inspect only, no file written):
    python sl_apply.py --matrix matrix.docx --manifest changes.json --dry-run

    # Apply and write output:
    python sl_apply.py --matrix matrix.docx --manifest changes.json --output matrix_revised.docx

    # Apply with custom audit log path:
    python sl_apply.py --matrix matrix.docx --manifest changes.json \
                       --output matrix_revised.docx --audit audit.json

Manifest format
---------------
{
  "meta": {
    "course":      "ALSAP_vCUR_.story",
    "cycle":       "2026-06",
    "author":      "Trainstorm",
    "description": "Review cycle 1 — reconciled against SOP-AST-29080 v1.0"
  },
  "changes": [
    {
      "id":             "<Storyline element ID>",
      "slide":          "SCE300_110",
      "element_type":   "TextBox",
      "disposition":    "REVISE",
      "canon_basis":    "SOP-AST-29080 constraint: unblinded data...",
      "reviewer":       "Mehetabel Kirschner",
      "segment_index":  0,
      "run_index":      0,
      "new_text":       "ALSAP provides a structured framework...",
      "notes":          "Bold formatting preserved"
    }
  ]
}

Field reference
---------------
id              Storyline element ID from the matrix (column 0).  Required.
slide           Slide name for human reference.  Optional.
element_type    Element type label for human reference.  Optional.
disposition     REVISE | VERIFY | DEV_FIX | DEFERRED.
                Only REVISE entries are applied; others are logged and skipped.
canon_basis     Rationale string for the audit trail.  Optional.
reviewer        Source reviewer name.  Optional.
segment_index   Which row within the ID group to target (0 = first, 1 = second…).
                Defaults to 0.  Required when an element spans multiple rows.
run_index       Which run within the Translation cell paragraph to modify.
                Defaults to 0.
new_text        Replacement text.  Required for REVISE.

Design notes
------------
- IDs are ephemeral within a single export/import cycle; the script
  rebuilds the ID→row mapping from the live matrix at runtime.
- Changes are addressed by (id, segment_index) so row indices never
  need to be hardcoded.
- Empty-string new_text is allowed to clear a run (e.g. collapsing
  residual bold runs after a paragraph rewrite).
- The Translation cell's run formatting (bold, italic) is preserved;
  only the text content is replaced.
- If an ID appears in the manifest but is not found in the matrix the
  entry is recorded as MISSING in the audit log and processing
  continues.
"""

import argparse
import json
import shutil
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

try:
    from docx import Document
except ImportError:
    sys.exit("python-docx is required: pip install python-docx")


# ─────────────────────────────────────────────────────────────────────────────
# Matrix parsing
# ─────────────────────────────────────────────────────────────────────────────

def parse_matrix(doc):
    """
    Return a dict mapping element_id -> list of row indices (in order).

    The Storyline translation matrix repeats the element ID in column 0
    for every row belonging to that element (including continuation rows
    for multi-segment text).  Column 1 (Type) and column 2 (Source Text)
    are blank on continuation rows; only column 3 (Translation) carries
    the segment text.
    """
    table = max(doc.tables, key=lambda t: len(t.rows))
    id_to_rows = defaultdict(list)

    for i, row in enumerate(table.rows):
        cell_id = row.cells[0].text.strip()
        # Skip the header row (contains "ID 🔒") and any empty-ID rows
        # that don't belong to a known element.
        if not cell_id or cell_id.startswith("ID"):
            continue
        id_to_rows[cell_id].append(i)

    return table, id_to_rows


# ─────────────────────────────────────────────────────────────────────────────
# Apply a single change
# ─────────────────────────────────────────────────────────────────────────────

def apply_change(table, row_idx, run_idx, new_text):
    """
    Replace the text of a specific run in the Translation cell (column 3)
    of the given row.  Returns the old text that was replaced.
    """
    cell = table.rows[row_idx].cells[3]
    para = cell.paragraphs[0]

    if run_idx >= len(para.runs):
        raise IndexError(
            f"run_index {run_idx} out of range "
            f"(paragraph has {len(para.runs)} run(s))"
        )

    run = para.runs[run_idx]
    old_text = run.text
    run.text = new_text
    return old_text


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Apply a change manifest to a Storyline translation matrix."
    )
    parser.add_argument("--matrix",   required=True,  help="Path to the matrix DOCX")
    parser.add_argument("--manifest", required=True,  help="Path to the change manifest JSON")
    parser.add_argument("--output",   default=None,   help="Output DOCX path (omit with --dry-run)")
    parser.add_argument("--audit",    default=None,   help="Audit log output path (JSON)")
    parser.add_argument("--dry-run",  action="store_true",
                        help="Report what would change without writing any files")
    args = parser.parse_args()

    # ── Load manifest ────────────────────────────────────────────────
    manifest_path = Path(args.manifest)
    if not manifest_path.exists():
        sys.exit(f"Manifest not found: {manifest_path}")
    with open(manifest_path, encoding="utf-8") as f:
        manifest = json.load(f)

    meta    = manifest.get("meta", {})
    changes = manifest.get("changes", [])

    if not changes:
        sys.exit("Manifest contains no changes.")

    # ── Load matrix ──────────────────────────────────────────────────
    matrix_path = Path(args.matrix)
    if not matrix_path.exists():
        sys.exit(f"Matrix not found: {matrix_path}")

    if not args.dry_run:
        if not args.output:
            sys.exit("--output is required unless --dry-run is set.")
        output_path = Path(args.output)
        shutil.copy(matrix_path, output_path)
        doc = Document(str(output_path))
    else:
        doc = Document(str(matrix_path))

    table, id_to_rows = parse_matrix(doc)

    # ── Process changes ──────────────────────────────────────────────
    audit_entries = []
    counts = {"applied": 0, "skipped": 0, "missing": 0, "error": 0}

    for entry in changes:
        element_id    = entry.get("id", "").strip()
        disposition   = entry.get("disposition", "REVISE").upper()
        segment_index = int(entry.get("segment_index", 0))
        run_index     = int(entry.get("run_index", 0))
        new_text      = entry.get("new_text", "")

        audit = {
            "id":           element_id,
            "slide":        entry.get("slide", ""),
            "element_type": entry.get("element_type", ""),
            "disposition":  disposition,
            "canon_basis":  entry.get("canon_basis", ""),
            "reviewer":     entry.get("reviewer", ""),
            "segment_index": segment_index,
            "run_index":    run_index,
            "status":       None,
            "old_text":     None,
            "new_text":     new_text,
            "notes":        entry.get("notes", ""),
        }

        # Only REVISE entries are applied
        if disposition != "REVISE":
            audit["status"] = f"SKIPPED ({disposition})"
            counts["skipped"] += 1
            audit_entries.append(audit)
            continue

        # Resolve element ID to row list
        rows = id_to_rows.get(element_id)
        if not rows:
            audit["status"] = "MISSING"
            counts["missing"] += 1
            audit_entries.append(audit)
            print(f"  [MISSING]  {element_id}  (slide: {entry.get('slide', '?')})")
            continue

        if segment_index >= len(rows):
            audit["status"] = (
                f"ERROR: segment_index {segment_index} out of range "
                f"(element has {len(rows)} segment(s))"
            )
            counts["error"] += 1
            audit_entries.append(audit)
            print(f"  [ERROR]    {element_id}  segment {segment_index} — "
                  f"element only has {len(rows)} segment(s)")
            continue

        row_idx = rows[segment_index]

        # Dry-run: report only
        if args.dry_run:
            cell = table.rows[row_idx].cells[3]
            para = cell.paragraphs[0]
            if run_index < len(para.runs):
                old_text = para.runs[run_index].text
            else:
                old_text = f"<run {run_index} does not exist>"
            print(
                f"  [DRY-RUN]  {element_id}\n"
                f"             slide={entry.get('slide','?')}  "
                f"seg={segment_index}  run={run_index}\n"
                f"             OLD: {repr(old_text[:80])}\n"
                f"             NEW: {repr(new_text[:80])}"
            )
            audit["status"]   = "DRY_RUN"
            audit["old_text"] = old_text
            counts["applied"] += 1
            audit_entries.append(audit)
            continue

        # Apply
        try:
            old_text = apply_change(table, row_idx, run_index, new_text)
            audit["status"]   = "APPLIED"
            audit["old_text"] = old_text
            counts["applied"] += 1
            print(
                f"  [APPLIED]  {element_id}  "
                f"(slide: {entry.get('slide','?')}, "
                f"seg:{segment_index}, run:{run_index})"
            )
        except Exception as exc:
            audit["status"] = f"ERROR: {exc}"
            counts["error"] += 1
            print(f"  [ERROR]    {element_id}  — {exc}")

        audit_entries.append(audit)

    # ── Save modified matrix ─────────────────────────────────────────
    if not args.dry_run:
        doc.save(str(output_path))
        print(f"\nOutput written: {output_path}")

    # ── Write audit log ──────────────────────────────────────────────
    audit_log = {
        "meta": {
            **meta,
            "matrix":      str(matrix_path),
            "manifest":    str(manifest_path),
            "output":      str(args.output) if args.output else None,
            "dry_run":     args.dry_run,
            "run_at":      datetime.now(timezone.utc).isoformat(),
            "counts":      counts,
        },
        "entries": audit_entries,
    }

    audit_path = Path(args.audit) if args.audit else None
    if audit_path:
        with open(audit_path, "w", encoding="utf-8") as f:
            json.dump(audit_log, f, indent=2, ensure_ascii=False)
        print(f"Audit log written: {audit_path}")

    # ── Summary ──────────────────────────────────────────────────────
    print(
        f"\nSummary: {counts['applied']} applied, "
        f"{counts['skipped']} skipped, "
        f"{counts['missing']} missing, "
        f"{counts['error']} errors."
    )

    if counts["error"] or counts["missing"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
