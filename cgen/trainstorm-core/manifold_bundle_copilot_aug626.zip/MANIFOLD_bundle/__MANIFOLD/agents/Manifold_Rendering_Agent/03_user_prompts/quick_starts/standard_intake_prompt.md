﻿# Standard Intake Prompt

Use this prompt to gather source artifacts, audience, task, output, constraints, and validation expectations.

